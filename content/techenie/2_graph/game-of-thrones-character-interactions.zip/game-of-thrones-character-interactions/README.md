# Game of thrones character interactions

A Pen created on CodePen.io. Original URL: [https://codepen.io/mlnchkdv/pen/OJGQExo](https://codepen.io/mlnchkdv/pen/OJGQExo).

Character Interaction Networks for the HBO Series "Game of Thrones" from all seasons. The data visualisation is made with D3.js and is forked from the following dataset : https://github.com/mathbeveridge/gameofthrones (forked 
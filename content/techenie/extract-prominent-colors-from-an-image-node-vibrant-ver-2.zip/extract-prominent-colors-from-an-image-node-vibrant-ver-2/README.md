# Extract prominent colors from an image (node-vibrant) ver. 2

A Pen created on CodePen.io. Original URL: [https://codepen.io/meldm/pen/RwOLpQy](https://codepen.io/meldm/pen/RwOLpQy).

Grab the dominant color palette from an image using just Javascript. 
https://github.com/Vibrant-Colors/node-vibrant
https://ru.vuejs.org/
# Extract prominent colors from an image (only vibrant.js) ver. 2

A Pen created on CodePen.io. Original URL: [https://codepen.io/meldm/pen/JjVMGeR](https://codepen.io/meldm/pen/JjVMGeR).

Grab the dominant color palette from an image using just Javascript. 
https://github.com/jariz/vibrant.js/
# js-weight-calc
![weightConv](https://user-images.githubusercontent.com/61211600/98983476-04e7b100-254b-11eb-9ff0-a489cb6e2f15.JPG)

## Mobile friendly
![co](https://user-images.githubusercontent.com/61211600/98983535-1761ea80-254b-11eb-94de-ec55b7254f9a.png)


# Text Intersection

This app is used to get unique items from list of text. It has two input field. User can enter comma separated text and check unique items from both side.
Remember only supported punctuation mark is comma.
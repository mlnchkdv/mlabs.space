## Dialog Window

### Demo

#### Initial Screen
![image](https://user-images.githubusercontent.com/61211600/211216293-9b177d64-a25d-46c7-a6ba-2cc2c5f016d5.png)

#### Dialog Screen
![image](https://user-images.githubusercontent.com/61211600/211216328-8036f8b7-ce8f-44dc-a5bd-caf788e1999c.png)

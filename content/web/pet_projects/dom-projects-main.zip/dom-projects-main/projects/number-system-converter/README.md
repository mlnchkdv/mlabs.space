# js-number-conversion

![nc](https://user-images.githubusercontent.com/61211600/99593362-c145e900-2a1b-11eb-87b2-c6ab74ff47ed.PNG)
![numberCon](https://user-images.githubusercontent.com/61211600/99593350-bdb26200-2a1b-11eb-805f-05908a3079e3.PNG)
